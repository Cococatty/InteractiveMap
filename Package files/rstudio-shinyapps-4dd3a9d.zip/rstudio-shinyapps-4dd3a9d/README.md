shinyapps
=======================================================

## Installation

To install directly from GitHub, run this:

```r
if (!require("devtools"))
  install.packages("devtools")
devtools::install_github("rstudio/shinyapps")
```

## Usage

To get started using ShinyApps checkout the [Getting Started Guide](http://shiny.rstudio.com/articles/shinyapps.html).
